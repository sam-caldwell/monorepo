//go:build tools

package winio

import _ "golang.org/x/tools/cmd/stringer"
