// This file only exists to allow go get on non-Windows platforms.

package backuptar
