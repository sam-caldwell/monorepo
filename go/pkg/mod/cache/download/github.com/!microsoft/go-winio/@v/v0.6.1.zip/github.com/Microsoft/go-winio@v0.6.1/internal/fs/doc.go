// This package contains Win32 filesystem functionality.
package fs
