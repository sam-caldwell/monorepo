// Package bufpipe provides a IO pipe, has variable-sized buffer.
package bufpipe
